# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sockets_framework']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['sockets_framework = sockets_framework:cli']}

setup_kwargs = {
    'name': 'sockets-framework',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Anatolio Nikiforidis',
    'author_email': 'nikiforova693@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/anatolio-deb/sockets-framework',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
